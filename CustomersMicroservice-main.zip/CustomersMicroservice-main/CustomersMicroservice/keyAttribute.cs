﻿using System;

namespace CustomersMicroservice
{
    internal class keyAttribute : Attribute
    {
    }
}