﻿using System;

namespace ManagerMicroservice
{
    internal class keyAttribute : Attribute
    {
    }
}