﻿namespace AuthenticationManagement.API
{
    public class Admin
    {
        public string Id { get; set; }
        public string Location { get; set; }
        public AppUser AppUser { get; set; }
    }
}
